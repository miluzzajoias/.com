import { db, doc, getDoc } from './firebase.js';
import { addToCart } from './cart.js';
const WA='5563985003751';
const root=document.querySelector('#detail');
const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const id=new URLSearchParams(location.search).get('id');
document.querySelector('#year')?.append(new Date().getFullYear());

async function init(){
  if(!id){root.innerHTML='<section class="empty-detail"><h1>Produto não encontrado</h1><a class="btn" href="index.html">Voltar para a coleção</a></section>';return;}
  try{
    const snap=await getDoc(doc(db,'produtos',id));
    if(!snap.exists()) throw new Error('not found');
    const p={id:snap.id,...snap.data()};
    document.title=`${p.name||'Produto'} | Miluzza Joias`;
    const price=p.price||'';
    const message=encodeURIComponent(`Olá! Tenho interesse na peça "${p.name||'Miluzza Joias'}"${p.code?` (código ${p.code})`:''}.`);
    root.innerHTML=`<div class="detail-media">${p.image?`<img src="${esc(p.image)}" alt="${esc(p.name)}">`:'<div class="placeholder">M</div>'}</div><div class="detail-content"><span class="detail-cat">${esc(p.category||'Miluzza Joias')}</span><h1 class="detail-title">${esc(p.name||'Peça Miluzza')}</h1>${price?`<div class="detail-price">${esc(price)}</div>`:''}<p class="detail-description">${esc(p.description||'Uma peça selecionada com o cuidado e a elegância da Miluzza Joias.')}</p><div class="detail-meta">${p.code?`<span>Código: ${esc(p.code)}</span>`:''}<span>${esc(p.status||'Disponível')}</span></div><div class="detail-actions"><button id="addDetail" class="btn">Adicionar ao carrinho</button><a class="interest" href="https://wa.me/${WA}?text=${message}" target="_blank" rel="noopener">Comprar pelo WhatsApp</a></div></div>`;
    $('#addDetail')?.addEventListener('click',()=>{addToCart(p);const b=$('#addDetail');b.textContent='Adicionado ao carrinho ✓';setTimeout(()=>b.textContent='Adicionar ao carrinho',1500);});
  }catch(e){root.innerHTML='<section class="empty-detail"><h1>Produto não encontrado</h1><p>Essa peça pode ter sido removida ou não está disponível.</p><a class="btn" href="index.html">Voltar para a coleção</a></section>';}
}
init();
